#!/bin/bash
[ ! -d '/tmp/cache' ] && mkdir -p /tmp/cache
export PORT=${PORT:-3000}
export HOSTNAME="0.0.0.0"
exec node server.js
