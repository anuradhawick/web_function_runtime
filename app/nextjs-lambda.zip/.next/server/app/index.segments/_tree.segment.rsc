:HL["/_next/static/chunks/1zeq8kbmv12w2.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
1:[["children",{"s":"__PAGE__","h":49314}]]
0:{"b":"XgyCsQEpajnjG5RQ3HSlY","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
