globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/XgyCsQEpajnjG5RQ3HSlY/_buildManifest.js",
    "static/XgyCsQEpajnjG5RQ3HSlY/_ssgManifest.js",
    "static/XgyCsQEpajnjG5RQ3HSlY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3vd8vxhajp3oh.js",
    "static/chunks/2865e-gezwe-l.js",
    "static/chunks/12p6pd1g4ps87.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/3vd8vxhajp3oh.js",
        "static/chunks/2865e-gezwe-l.js",
        "static/chunks/12p6pd1g4ps87.js"
      ],
      "runtimeModuleIds": [
        20736
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3vd8vxhajp3oh.js",
        "static/chunks/2865e-gezwe-l.js",
        "static/chunks/12p6pd1g4ps87.js"
      ],
      "runtimeModuleIds": [
        20736
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3vd8vxhajp3oh.js",
        "static/chunks/2865e-gezwe-l.js",
        "static/chunks/12p6pd1g4ps87.js"
      ],
      "runtimeModuleIds": [
        20736
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
